import React, { Component } from 'react'

const textStyle = {
    fontFamily: "Open Sans", 
    fontSize: "14", 
    fontWeight: "bold"
}

class Logo extends Component {
    
    render() {
        return (
            <svg width="200px" height="60px" viewBox="0 0 103 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                    <g id="Artboard" fill="#FFFFFF">
                        <g id="Group" transform="translate(1.000000, 2.000000)">
                            <text x="25" y="12" fill="white" style={textStyle}>Online</text>
                            <text x="69" y="12" fill="#007EE5" style={textStyle}>Shop</text>
                            <path d="M3.76471391,9.51995983 C7.64366703,6.63032857 12.804137,2.22535306 17.0482566,1.21450981 C18.4395815,0.883130986 20.2648226,0.875033614 21.8954625,1.59091492 C24.7124589,2.82762887 23.5109502,5.5150732 23.5109502,5.5150732 C23.5109502,5.5150732 22.2730781,3.84566499 19.2479938,5.5150732 C17.4551113,6.50448457 17.0343671,8.32725373 17.9611743,9.65608156 C18.8879814,10.9849094 24,12.9932827 24,12.9932827 C24,12.9932827 16.3872515,13.0111423 0,12.9932827" id="Path"></path>
                        </g>
                    </g>
                </g>
            </svg>
        )
    }
}

export default Logo