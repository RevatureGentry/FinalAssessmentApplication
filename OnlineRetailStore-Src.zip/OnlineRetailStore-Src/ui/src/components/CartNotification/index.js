import React, {PropTypes} from 'react';
import {VelocityComponent} from 'velocity-react';

const  divStyle = {
	color:'Yellow',	
  fontWeight:'bold'  
};

const CartNotification = ({showItemAdded}) => {  
  return (
    <VelocityComponent
        animation={{opacity: showItemAdded ? 1 : 0}}
        duration={500}
    >
    <div style={divStyle}> Added to your cart </div>
    </VelocityComponent>
  );
};

CartNotification.propTypes = {
  showItemAdded: PropTypes.bool.isRequired,
};

CartNotification.defaultProps = {
  showItemAdded: false,
};

export default CartNotification;
