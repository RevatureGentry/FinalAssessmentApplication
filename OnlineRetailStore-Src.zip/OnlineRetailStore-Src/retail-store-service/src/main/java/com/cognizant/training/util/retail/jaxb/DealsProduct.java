package com.cognizant.training.util.retail.jaxb;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "product")
@XmlType(propOrder = { "strDescription", "strVersion", "dcCatalog_item"})
public class DealsProduct {
	
	private String strDescription;
	private String strVersion;
	private DealsCatalogItem dcCatalog_item;
	
	public String getStrDescription() {
		return strDescription;
	}
	@XmlAttribute
	public void setStrDescription(String strDescription) {
		this.strDescription = strDescription;
	}
	public String getStrVersion() {
		return strVersion;
	}
	@XmlAttribute
	public void setStrVersion(String strVersion) {
		this.strVersion = strVersion;
	}	
	
	public DealsCatalogItem getDcCatalog_item() {
		return dcCatalog_item;
	}
	@XmlElement(name = "catalog_item")
	public void setDcCatalog_item(DealsCatalogItem dcCatalog_item) {
		this.dcCatalog_item = dcCatalog_item;
	}

	
	
}