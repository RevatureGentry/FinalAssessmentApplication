package com.cognizant.training.util.retail.configuration;

import org.springframework.context.annotation.Bean;

import com.cognizant.training.util.retail.service.CustomerService;
import com.cognizant.training.util.retail.service.CustomerServiceImpl;
import com.cognizant.training.util.retail.service.DriverManagerService;
import com.cognizant.training.util.retail.service.DriverManagerServiceImpl;
import com.cognizant.training.util.retail.service.OrderService;
import com.cognizant.training.util.retail.service.OrderServiceImpl;
import com.cognizant.training.util.retail.service.ProductService;
import com.cognizant.training.util.retail.service.ProductServiceImpl;

public class BeanConfiguration {

	@Bean
	public CustomerService customerService() {
		return new CustomerServiceImpl();
	}
	
	@Bean
	public OrderService orderService() {
		return new OrderServiceImpl();
	}
	
	@Bean
	public ProductService productService() {
		return new ProductServiceImpl();
	}

	@Bean
	public DriverManagerService driverManagerService()
	{
		return new DriverManagerServiceImpl();
	}
}
