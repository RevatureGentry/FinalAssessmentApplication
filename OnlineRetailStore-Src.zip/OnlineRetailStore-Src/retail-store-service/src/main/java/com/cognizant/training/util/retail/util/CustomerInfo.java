package com.cognizant.training.util.retail.util;

import org.json.JSONObject;
import com.cognizant.training.util.retail.model.Customer;

public class CustomerInfo {

	public JSONObject getCustomerInfo(Customer customer) {
		JSONObject customerInfo = new JSONObject();
		customerInfo.put("customerIf", customer.getCustomerId());
		customerInfo.put("name", customer.getName());
		customerInfo.put("username", customer.getUsername());
		customerInfo.put("email", customer.getEmail());
		customerInfo.put("phone", customer.getPhone());
		customerInfo.put("address", customer.getAddress());

		return customerInfo;
	}

}
