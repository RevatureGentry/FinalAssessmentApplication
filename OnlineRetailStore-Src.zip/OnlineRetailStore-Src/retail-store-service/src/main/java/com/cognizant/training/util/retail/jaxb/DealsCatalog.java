package com.cognizant.training.util.retail.jaxb;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "catalog")
@XmlType(propOrder = { "dpProduct"})
public class DealsCatalog {

	private DealsProduct dpProduct;

	public DealsProduct getDpProduct() {
		return dpProduct;
	}
	@XmlElement(name = "product")
	public void setDpProduct(DealsProduct dpProduct) {
		this.dpProduct = dpProduct;
	}
	
}