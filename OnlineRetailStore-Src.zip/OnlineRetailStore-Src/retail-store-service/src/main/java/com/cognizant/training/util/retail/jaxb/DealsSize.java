package com.cognizant.training.util.retail.jaxb;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "size")
@XmlType(propOrder = { "description", "color_swatch"})
public class DealsSize {

	private String description;
	private String color_swatch;
	
	public String getDescription() {
		return description;
	}

	@XmlAttribute
	public void setDescription(String description) {
		this.description = description;
	}

	public String getColor_swatch() {
		return color_swatch;
	}

	@XmlElement(name = "color_swatch")
	public void setColor_swatch(String color_swatch) {
		this.color_swatch = color_swatch;
	}
}
