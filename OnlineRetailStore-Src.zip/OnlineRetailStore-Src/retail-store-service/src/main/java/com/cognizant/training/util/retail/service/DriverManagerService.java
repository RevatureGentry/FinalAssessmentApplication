package com.cognizant.training.util.retail.service;

import java.util.List;

import com.cognizant.training.util.retail.model.Product;

public interface DriverManagerService {
	
	public List<Product> getProductUsingDriverManager();

}
