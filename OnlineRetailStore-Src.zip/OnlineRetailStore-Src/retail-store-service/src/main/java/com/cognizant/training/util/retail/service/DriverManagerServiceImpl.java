package com.cognizant.training.util.retail.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.training.util.retail.model.Product;

@Service("driverManagerService")
@Transactional
public class DriverManagerServiceImpl implements DriverManagerService {

	public static final Logger logger = LoggerFactory.getLogger(DriverManagerServiceImpl.class);

	@Autowired
	private Environment environment;

	public DataSourceProperties dataSourceProperties() {
		DataSourceProperties dataSourceProperties = new DataSourceProperties();

		return dataSourceProperties;
	}

	public List<Product> getProductUsingDriverManager() {

		List<Product> productList = new ArrayList<Product>();

		try {
			Connection con = DriverManager.getConnection(environment.getRequiredProperty("spring.datasource.url"),
					environment.getRequiredProperty("spring.datasource.username"),
					environment.getRequiredProperty("spring.datasource.password"));

			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery("select * from product where status = 'true'");

			while (rs.next()) {
				Product product = new Product();

				product.setProductId(rs.getLong(1));
				product.setDescription(rs.getString(2));
				product.setImage(rs.getString(3));
				product.setName(rs.getString(4));
				product.setStatus(rs.getString(5));
				product.setPrice(rs.getDouble(6));

				productList.add(product);
			}

		} catch (Exception e) {
			logger.warn("An exception occurred while writing Product details to File: ", e);
			e.printStackTrace();
		}
		return productList;

	}

}
