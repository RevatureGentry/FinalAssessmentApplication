package com.cognizant.training.util.retail;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.training.util.retail.configuration.JpaConfiguration;

@EnableAutoConfiguration
@Import(JpaConfiguration.class)
@SpringBootApplication(scanBasePackages = { "com.cognizant.training.util.retail" })
@EntityScan("com.cognizant.training.util.retail.model")
@EnableJpaRepositories("com.cognizant.training.util.retail.repository")

public class RetailApplicationService {

	static Logger logger = LoggerFactory.getLogger(RetailApplicationService.class);

	public static Map<String,Object> allProducts = new HashMap();
	
	public static void main(String[] args) {
		SpringApplication.run(RetailApplicationService.class, args);
	}

}
