package com.cognizant.training.util.retail.repositories;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.training.util.retail.model.Product;

@Repository
@Transactional
public interface ProductRepository extends JpaRepository<Product, Long> {
	
	Product findByName(String name);
	
	List<Product> findByStatusIgnoreCase(String status);
	
	long countByStatusIgnoreCase(String status);
	
	Page<Product> findByStatusIgnoreCase(String status,Pageable pageable);
}
