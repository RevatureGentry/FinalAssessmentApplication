package com.cognizant.training.util.retail.service;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.training.util.retail.RetailApplicationService;
import com.cognizant.training.util.retail.jaxb.DealsCatalog;
import com.cognizant.training.util.retail.model.Product;
import com.cognizant.training.util.retail.repositories.ProductRepository;
import com.cognizant.training.util.retail.util.CallableWorker;

@Service("productService")
@Transactional
public class ProductServiceImpl implements ProductService {

	static Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	ThreadPoolTaskExecutor threadPool;
	
	

	public List<Product> findAllProducts() {
		List<Product> products = new ArrayList<Product>();
		products = productRepository.findAll();

		getTextSemantics(products, "findAllProducts");

		for (int i = 0; i < 25000; i++) {
			RetailApplicationService.allProducts.put(System.currentTimeMillis() + "" + i, "Sample" + i);
		}
		return productRepository.findAll();
	}

	@SuppressWarnings({ "unused" })
	private void getTextSemantics(List<Product> products, String strMethod) {

		List<String> productName = products.stream().map(pName -> pName.getName().split(" ")[0])
				.collect(Collectors.toCollection(() -> new ArrayList<String>()));

		Map<String, Long> mapWords = productName.stream().collect(Collectors.groupingBy(w -> w, Collectors.counting()));

		List<Map.Entry<String, Long>> result = mapWords.entrySet().stream()
				.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).limit(10).collect(Collectors.toList());

	}

	private void getCurrentDeals() {

		try {
			JAXBContext contextJAXB;
			contextJAXB = JAXBContext.newInstance(DealsCatalog.class);

			contextJAXB.createUnmarshaller().unmarshal(new FileReader("./deals.xml"));

		} catch (JAXBException e1) {
			e1.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	public Product findByName(String name) {
		return productRepository.findByName(name);
	}

	public Product findById(Long productId) {

		if (productId == 5) {
			long n = 0;
			n = Math.round(Math.random() * 30);

			while (n > 0) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				n--;
			}
		}

		return productRepository.findOne(productId);
	}
	
	public List<Product> findAllProductsByStatus(String status) {

		
		List<Product> products=getProductList(status);
		logger.error("ProductList"+ products);
        getTextSemantics(products, "findAllProductsByStatus");
		for (int i = 0; i < 25000; i++) {
			RetailApplicationService.allProducts.put(System.currentTimeMillis() + "" + i, "Sample" + i);
			getCurrentDeals();
		}		
		return productRepository.findByStatusIgnoreCase(status);
	}
	
	private List<Product> getProductList(String status) {
		List<Product> products=new ArrayList<>();
        List<Future<List<Product>>> futureList = new ArrayList<>();
        long count= productRepository.countByStatusIgnoreCase(status);
        int maxOffset=1;
        if(count>250) {
        	maxOffset = (int) count/4;
        	if(count > (4*maxOffset)) {
        		maxOffset=maxOffset+1;
        	}
        }
        for(int offset = 0; offset < maxOffset; offset ++){
            CallableWorker callableTask = new CallableWorker(status,offset,250,productRepository);
            Future<List<Product>> result = threadPool.submit(callableTask);
            futureList.add(result);
        }
         
        for(Future<List<Product>> future: futureList){
            try {
            	products.addAll(future.get());
            } catch (Exception e){
            	logger.error("Exception occured"+e.getMessage());
            }
        }
         
        return products;
	}
	
}