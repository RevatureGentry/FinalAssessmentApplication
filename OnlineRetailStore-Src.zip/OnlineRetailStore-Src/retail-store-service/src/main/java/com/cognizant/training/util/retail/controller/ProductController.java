package com.cognizant.training.util.retail.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.training.util.retail.model.Product;
import com.cognizant.training.util.retail.service.DriverManagerService;
import com.cognizant.training.util.retail.service.ProductService;
import com.cognizant.training.util.retail.util.CustomErrorType;

@RestController
@RequestMapping("/retail/api")
public class ProductController {
	public static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	ProductService productService;
	
	@Autowired
	private Environment environment;

	@Autowired
	DriverManagerService driverManagerService;

	
	// -------------------------------------------------------------------
	//                   Product methods
	//--------------------------------------------------------------------


	// -------------------Retrieve All Products---------------------------------------------
	@SuppressWarnings({ "unused" })
	@RequestMapping(value = "/product/", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> listAllProducts() {
		List<Product> products = productService.findAllProductsByStatus("true");
		if (products.isEmpty()) {
			return new ResponseEntity<List<Product>>(HttpStatus.NO_CONTENT);
		}
		
		storeProductDetailsInFile(products);
		List<Product> productList = driverManagerService.getProductUsingDriverManager();
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

	/**
	 * This method stores all the product details in a Text file
	 * 
	 * @param products
	 */
	@SuppressWarnings({ "resource" })
	private void storeProductDetailsInFile(List<Product> products) {

		String filePath = environment.getRequiredProperty("file.path");

		try {
			File file = new File(filePath);
			if (file.exists()) {
				file.delete();
			}
			file.createNewFile();
			FileWriter fileWriter = new FileWriter(file);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			String lineSeparator = environment.getRequiredProperty("line.separator");
			for (int i = 0; i < products.size(); i++) {
				bufferedWriter.write(products.get(i).toString() + lineSeparator);
			}
		} catch (Exception e) {
			logger.warn("An exception occurred while writing Product details to File: ", e);
			e.printStackTrace();
		}
	}
	// -------------------Retrieve Single Product By Id------------------------------------------

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/product/{productId}", method = RequestMethod.GET)
	public ResponseEntity<?> getProduct(@PathVariable("productId") long productId) {
		logger.info("Fetching Product with id {}", productId);
		Product product = productService.findById(productId);
		if (product == null) {
			logger.error("Product with id {} not found.", productId);
			return new ResponseEntity(new CustomErrorType("Product with id " + productId 
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
}
