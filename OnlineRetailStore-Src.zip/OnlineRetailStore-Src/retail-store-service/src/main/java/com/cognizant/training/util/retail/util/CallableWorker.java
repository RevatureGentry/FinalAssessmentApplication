package com.cognizant.training.util.retail.util;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.cognizant.training.util.retail.model.Product;
import com.cognizant.training.util.retail.repositories.ProductRepository;

public class CallableWorker implements  Callable<List<Product>> {
	 
    private static Logger logger = 
    		LoggerFactory.getLogger(CallableWorker.class);
    
    
    private String status;
    private Integer offset;
    private Integer maxElements;
 
    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getOffset() {
		return offset;
	}

	public void setOffset(Integer offset) {
		this.offset = offset;
	}

	public Integer getMaxElements() {
		return maxElements;
	}

	public void setMaxElements(Integer maxElements) {
		this.maxElements = maxElements;
	}

	
	
	private ProductRepository productRepository;
 
    public CallableWorker(String status,Integer offset,Integer maxElements,ProductRepository productRepository) {
    	this.status=status;
    	this.offset=offset;
    	this.maxElements=maxElements;
    	this.productRepository=productRepository;
    }
 
    @Override
    public List<Product> call() throws InterruptedException {      
    	Pageable pageWithMaxElements = new PageRequest(offset,maxElements);
		Page<Product> productPage= productRepository.findByStatusIgnoreCase(status, pageWithMaxElements);
		List<Product> productList=productPage.getContent();
		Thread.sleep(100);
		return productList;
    }
 

}
