package com.cognizant.training.util.retail.service;

import java.util.List;

import com.cognizant.training.util.retail.model.Product;

public interface ProductService {

	Product findByName(String name);

	List<Product> findAllProducts();

	Product findById(Long productId);
	
	List<Product> findAllProductsByStatus(String status);

}
