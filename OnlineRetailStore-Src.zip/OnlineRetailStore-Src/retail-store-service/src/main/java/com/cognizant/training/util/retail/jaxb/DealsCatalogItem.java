package com.cognizant.training.util.retail.jaxb;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "catalog_item")
@XmlType(propOrder = { "strGender", "strItem_number" ,"fPrice" , "dsdealSize"})
public class DealsCatalogItem {

	private String strGender;	
	
	private String strItem_number;	
	private float fPrice;
	private DealsSize dsdealSize;
	
	public String getStrGender() {
		return strGender;
	}
	@XmlElement(name = "strGender")
	public void setStrGender(String strGender) {
		this.strGender = strGender;
	}
	
	public String getStrItem_number() {
		return strItem_number;
	}
	@XmlElement(name = "item_number")
	public void setStrItem_number(String strItem_number) {
		this.strItem_number = strItem_number;
	}
	public float getfPrice() {
		return fPrice;
	}
	@XmlElement(name = "price")
	public void setfPrice(float fPrice) {
		this.fPrice = fPrice;
	}
	public DealsSize getDsdealSize() {
		return dsdealSize;
	}
	@XmlElement(name = "size")
	public void setDsdealSize(DealsSize dsdealSize) {
		this.dsdealSize = dsdealSize;
	}
	
	
}